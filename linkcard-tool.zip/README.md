# LinkCard — Image Link Generator (piclinks jaisa tool)

Image upload karo → short link milta hai → Facebook/WhatsApp pe share karo to custom image + description ke saath preview dikhta hai, aur user click karte hi target URL pe redirect ho jata hai.

## Kaise Deploy Karein (Netlify)

### Step 1: Netlify pe naya site banayein
1. https://app.netlify.com pe login karein
2. **Add new site → Deploy manually** (ya GitHub se connect karein agar repo bana lein)
3. Is poore `piclinks-tool` folder ko zip karke drag-drop karein, YA GitHub pe push karke Netlify se connect karein

### Step 2: Netlify Blobs enable karna
Netlify Blobs automatically enabled hota hai jab aap Netlify Functions deploy karte hain — koi extra setup nahi chahiye. Bas ye zaroori hai ke aap **Netlify CLI se deploy karein ya GitHub-connected site** ho (drag-drop wale "manual deploy" mein Functions kaam nahi karte).

**Recommended tareeqa — GitHub ke zariye:**
1. Is folder ko GitHub repo mein push karein
2. Netlify pe **Import from Git** karein, apna repo select karein
3. Build settings automatically `netlify.toml` se aa jayengi
4. Deploy dabayein

### Step 3: Test karein
1. Apni site URL kholein (e.g. `https://your-site.netlify.app`)
2. Image upload karein, redirect URL aur description bharein
3. "Generate Link" dabayein
4. Milne wala link (`.../l/xxxxx`) Facebook pe post karke test karein

## Kaise Kaam Karta Hai

- `/l/CODE` link khulte hi function check karta hai ke request **Facebook/WhatsApp crawler** se aa rahi hai ya **real user** se
  - Crawler ho to: sirf OG tags (image, title, description) wala page dikhata hai
  - Real user ho to: 2 second baad target URL pe redirect kar deta hai (taake crawler ko OG tags parhne ka time mil jaye)
- Image `/img/CODE` route se serve hoti hai, Netlify Blob storage se
- Har link ka data (redirect URL, description, clicks count) bhi Blob storage mein save hota hai

## Custom Domain Lagana

Agar apna Hostinger domain use karna hai:
1. Netlify site settings → Domain management → Add custom domain
2. Hostinger DNS mein Netlify ke diye gaye nameservers ya A/CNAME record daalein
3. Netlify khud SSL certificate laga dega
